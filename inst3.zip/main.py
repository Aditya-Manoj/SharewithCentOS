import os
import logging
import socket
import time


for file in os.listdir("./"):
    if file.endswith(".txt"):
        # print(os.path.join("/mydir", file))
        with open(file, "r") as f:
            # create a logger
            logger = logging.getLogger('json_logger')
            logger.setLevel(logging.DEBUG)

            # create a file handler and set the level to debug
            file_handler = logging.FileHandler(file.split(".txt")[0] + '.log')
            file_handler.setLevel(logging.DEBUG)

            # create a formatter that outputs logs in JSON format
            # json_formatter = logging.Formatter('{"time": "%(asctime)s", "level": "%(levelname)s", "message": "%(message)s"}')
            json_formatter = logging.Formatter('%(message)s')

            # set the formatter for the file handler
            file_handler.setFormatter(json_formatter)

            # add the file handler to the logger
            logger.addHandler(file_handler)

            while True:
                t = int(time.time())
                h = socket.gethostname()
                l = f.readline().split("\n")[0]
                if not l:
                    break
                Line = '{"timestamp": ' + str(t) + ', ' + l + '}'
                logger.debug(Line)
                print("Log Line appended")
                time.sleep(1)

print("LOG WRITE COMPLETE")